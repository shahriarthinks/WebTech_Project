# Blood Connect – Blood Bank Management System (Group 04, CSC 3215)

## Team work (who did what)
| Member | Part | Files |
|--------|------|-------|
| **Sadib** | Registration (Create Account), Admin pages, Forgot Password | Create Account tab in `login.html`, `register.js`, `admin.html`, `users.html`, `blood-stock.html`, `requests.html`, `donations.html`, `admin.js`, `forgot-password.html`, `forgot-password.js` |
| **Sadiha** | Login (Sign In) and Staff dashboard | Sign In tab in `login.html`, `login.js`, `staff.html`, `staff.js` |
| **Natasha** | Landing page and Medical Officer dashboard | `index.html`, `index.js`, `medical-officer.html`, `medical-officer.js` |
| **Sadia Mourin** | Donor and Receiver dashboards | `donor.html`, `receiver.html`, `donor-receiver.js` |

Each person's part is also written in a comment at the top of every HTML and JS file,
and at the top of each section in `style.css`.

## How to run in VS Code
1. Unzip `blood-connect.zip`.
2. Open VS Code, then **File > Open Folder...** and choose the **`blood-connect`** folder
   (the folder that has `index.html` inside it, not the folder above it).
3. VS Code will ask **"Do you want to install the recommended extensions?"** – click **Install**.
   This installs **Live Server** (the `.vscode` folder asks for it).
4. Run the site in any ONE of these ways:
   - **Go Live:** click **Go Live** at the bottom-right of VS Code. The site opens at
     `http://127.0.0.1:5500/index.html` and refreshes every time you save a file.
   - **Right-click** `index.html` > **Open with Live Server**.
   - **F5** (Run > Start Debugging) > choose **"Open Blood Connect in Chrome"** or
     **"... in Edge"**. This works even without Live Server.

The `.vscode` folder holds these settings. It is hidden on some computers, but VS Code shows it.

### Quick test after it opens
`index.html` > **Get Started** > choose a role (for example **Administrator**) >
type any username (3+ letters) and a password (8+ characters) > **Login**.

## How the pages connect
```
index.html  --Get Started-->  login.html
login.html (Sign In as ...)  -->  admin.html / staff.html / donor.html /
                                  medical-officer.html / receiver.html
Logout on any dashboard  -->  back to login.html (Medical Officer goes to index.html)
```

## One CSS file: style.css
All CSS is in **one file, `style.css`**, with one section per member.
Every page has a class on its `<body>`, and each section only styles pages with that class,
so one member's styles never change another member's page:

| body class | pages | section in style.css |
|------------|-------|----------------------|
| `landing-page` | index.html | 1 – Natasha |
| `login-page` | login.html, forgot-password.html | 2 – Sadiha (Sign In) and Sadib (Create Account) |
| `dashboard-page` | admin, users, blood-stock, requests, donations, staff | 3 – Sadib (Admin) and Sadiha (Staff) |
| `mo-page` | medical-officer.html | 4 – Natasha |
| `donor-receiver-page` | donor.html, receiver.html | 5 – Sadia Mourin |

## Notes
- All data is kept in the JavaScript files, so changes are lost when the page is refreshed.
  When the PHP part is ready, it will come from the database.
- The doctor photo on the landing page is loaded from the internet (unsplash.com).
  With no internet, the page shows `images/login-side.jpg` instead, so nothing looks broken.
