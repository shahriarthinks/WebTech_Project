/* =====================================================
   Blood Connect - medical-officer.js  (used by medical-officer.html)

   Team work (who did what):
   - Sadib        : Registration (Create Account), Admin pages, Forgot Password
   - Sadiha       : Login (Sign In) and Staff dashboard
   - Natasha      : Landing page and Medical Officer dashboard
   - Sadia Mourin : Donor and Receiver dashboards

   This file is done by Natasha.
   ===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    const approveButton = document.querySelector(".approve");
    const rejectButton = document.querySelector(".reject");

    const pendingCard = document.querySelector(
        ".card:nth-child(1) h2"
    );

    const approvedCard = document.querySelector(
        ".card:nth-child(2) h2"
    );

    const rejectedCard = document.querySelector(
        ".card:nth-child(3) h2"
    );

    const reviewTable = document.querySelector(".reviews table");


    

    if (approveButton) {

        approveButton.addEventListener("click", function () {

            if (confirm("Are you sure you want to approve this donor?")) {

                const donorRow = reviewTable.rows[1];

                const decisionCell = donorRow.cells[3];

                if (decisionCell.textContent.trim() !== "Pending") {
                    alert("This donor has already received a decision!");
                    return;
                }

                decisionCell.textContent = "Approved";
                decisionCell.className = "approved";

                pendingCard.textContent =
                    Math.max(0, Number(pendingCard.textContent) - 1);

                approvedCard.textContent =
                    Number(approvedCard.textContent) + 1;

                alert("Donor Approved Successfully!");

            }

        });

    }


    // ==================================
    // 4. DONOR REJECT FUNCTION
    // ==================================

    if (rejectButton) {

        rejectButton.addEventListener("click", function () {

            if (confirm("Are you sure you want to reject this donor?")) {

                const donorRow = reviewTable.rows[1];

                const decisionCell = donorRow.cells[3];

                if (decisionCell.textContent.trim() !== "Pending") {
                    alert("This donor has already received a decision!");
                    return;
                }

                decisionCell.textContent = "Rejected";
                decisionCell.className = "rejected";

                pendingCard.textContent =
                    Math.max(0, Number(pendingCard.textContent) - 1);

                rejectedCard.textContent =
                    Number(rejectedCard.textContent) + 1;

                alert("Donor Rejected Successfully!");

            }

        });

    }


    // ==================================
    // 5. LOGOUT FUNCTION
    // ==================================

    const menuLinks = document.querySelectorAll(".menu a");

    menuLinks.forEach(function (link) {

        if (link.textContent.trim() === "Logout") {

            link.addEventListener("click", function (event) {

                event.preventDefault();

                if (confirm("Are you sure you want to logout?")) {

                    window.location.href = "index.html";

                }

            });

        }

    });


   
    

    menuLinks.forEach(function (link) {

        if (link.textContent.trim() !== "Logout") {

            link.addEventListener("click", function (event) {

                event.preventDefault();

                alert(link.textContent + " section is selected.");

            });

        }

    });

});
