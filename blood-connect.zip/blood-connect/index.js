/* =====================================================
   Blood Connect - index.js  (used by index.html, the landing page)

   Team work (who did what):
   - Sadib        : Registration (Create Account), Admin pages, Forgot Password
   - Sadiha       : Login (Sign In) and Staff dashboard
   - Natasha      : Landing page and Medical Officer dashboard
   - Sadia Mourin : Donor and Receiver dashboards

   This file is done by Natasha.
   ===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    const startButton = document.getElementById("getStarted");

    if (startButton) {
        startButton.addEventListener("click", function () {
            window.location.href = "login.html";   // opens the Sign In / Create Account page
        });
    }

});
