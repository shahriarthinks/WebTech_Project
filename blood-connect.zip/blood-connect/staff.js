/* =====================================================
   Blood Connect - staff.js  (used by staff.html)

   Team work (who did what):
   - Sadib        : Registration (Create Account), Admin pages, Forgot Password
   - Sadiha       : Login (Sign In) and Staff dashboard
   - Natasha      : Landing page and Medical Officer dashboard
   - Sadia Mourin : Donor and Receiver dashboards
   This file is done by Sadiha.
   ===================================================== */


// ---------- Data (arrays of objects) ----------

let donors = [];
let donations = [];
let appointments = [];

let expiredUnits = [
  { id: "UNIT-5521", type: "A+", date: "August 24, 2026" },
  { id: "UNIT-5530", type: "O+", date: "August 26, 2026" },
  { id: "UNIT-5534", type: "B-", date: "August 27, 2026" }
];

// getDate() is in the practice sheet; getMonth() (0 = January) and
// getFullYear() work the same way for the month and the year.
let months = ["January", "February", "March", "April", "May", "June", "July",
              "August", "September", "October", "November", "December"];


// ---------- Helper functions ----------

// Show a message under a form. isError = true makes it red.
function showMessage(id, text, isError) {
  let message = document.getElementById(id);
  message.innerHTML = text;
  if (isError) {
    message.classList.add("critical");
  } else {
    message.classList.remove("critical");
  }
}

// Make one table cell, put text in it and add it to the row
function addCell(row, text, className) {
  let cell = document.createElement("td");
  cell.textContent = text;
  if (className !== "") {
    cell.classList.add(className);
  }
  row.appendChild(cell);
}

// Add one line to a list (ul)
function addListItem(listId, text) {
  const li = document.createElement("li");
  li.textContent = text;
  document.getElementById(listId).appendChild(li);
}

// Change "2026-09-01" (from a date input) into "September 1, 2026"
function formatDate(value) {
  let d = new Date(value + "T00:00:00");
  return months[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
}

// Update the four cards at the top
function updateCards() {
  document.getElementById("donorCount").textContent = donors.length;
  document.getElementById("donationCount").textContent = donations.length;
  document.getElementById("appointmentCount").textContent = appointments.length;
  document.getElementById("expiredCount").textContent = expiredUnits.length;
}


// ---------- Today's date and Logout ----------

let today = new Date();
document.getElementById("today").textContent =
  months[today.getMonth()] + " " + today.getDate() + ", " + today.getFullYear();

document.getElementById("logoutLink").addEventListener("click", function (event) {
  if (!confirm("Are you sure you want to logout?")) {
    event.preventDefault();   // stay on this page
  }
});


// ---------- Register Donor ----------

const donorForm = document.getElementById("donorForm");

donorForm.addEventListener("submit", function (event) {
  event.preventDefault();   // stops page reload on submit

  let name = document.getElementById("donorName").value.trim();
  let phone = document.getElementById("donorPhone").value.trim();
  let group = document.getElementById("donorGroup").value;

  if (name === "" || phone === "" || group === "") {
    showMessage("donorMessage", "Please fill all fields.", true);
    return;
  }

  if (!/^[A-Za-z. ]+$/.test(name) || name.length < 3) {
    showMessage("donorMessage", "Name must be at least 3 letters (letters, spaces and dots only).", true);
    return;
  }

  if (!/^01[3-9][0-9]{8}$/.test(phone)) {
    showMessage("donorMessage", "Phone must be 11 digits and start with 013 to 019.", true);
    return;
  }

  donors.push({ name: name, phone: phone, group: group });

  // Add the new row to the table
  let row = document.createElement("tr");
  addCell(row, name, "");
  addCell(row, phone, "");
  addCell(row, group, "type");
  document.getElementById("donorTable").appendChild(row);

  document.getElementById("noDonors").style.display = "none";
  showMessage("donorMessage", "Donor " + name + " added successfully!", false);
  donorForm.reset();
  updateCards();
});


// ---------- Record Donation ----------

const donationForm = document.getElementById("donationForm");

donationForm.addEventListener("submit", function (event) {
  event.preventDefault();

  let name = document.getElementById("donationName").value.trim();
  let group = document.getElementById("donationGroup").value;
  let units = document.getElementById("donationUnits").value;
  let number = Number(units);

  if (name === "" || group === "" || units.trim() === "") {
    showMessage("donationMessage", "Please enter valid information.", true);
    return;
  }

  if (!Number.isInteger(number) || number < 1 || number > 2) {
    showMessage("donationMessage", "A donor can give 1 or 2 units only.", true);
    return;
  }

  donations.push({ name: name, group: group, units: number });
  addListItem("donationList", name + " - " + group + " - " + number + " unit(s)");

  showMessage("donationMessage", "Donation saved!", false);
  donationForm.reset();
  updateCards();
});


// ---------- Schedule Appointment ----------

const appointmentForm = document.getElementById("appointmentForm");

appointmentForm.addEventListener("submit", function (event) {
  event.preventDefault();

  let name = document.getElementById("appointmentName").value.trim();
  let dateValue = document.getElementById("appointmentDate").value;

  if (name === "" || dateValue === "") {
    showMessage("appointmentMessage", "Enter name and date.", true);
    return;
  }

  // The date must be from today up to 30 days later
  let start = new Date();
  start.setHours(0, 0, 0, 0);
  let lastDay = new Date(start);
  lastDay.setDate(start.getDate() + 30);
  let chosen = new Date(dateValue + "T00:00:00");

  if (chosen < start) {
    showMessage("appointmentMessage", "Appointment date cannot be in the past.", true);
    return;
  } else if (chosen > lastDay) {
    showMessage("appointmentMessage", "Choose a date within the next 30 days.", true);
    return;
  }

  appointments.push({ name: name, date: dateValue });
  addListItem("appointmentList", name + " - " + formatDate(dateValue));

  showMessage("appointmentMessage", "Appointment added!", false);
  appointmentForm.reset();
  updateCards();
});


// ---------- Expired Blood Stock ----------

function showExpired() {
  let table = document.getElementById("expiredTable");
  table.innerHTML = "";   // remove the old rows

  expiredUnits.forEach(function (unit) {
    let row = document.createElement("tr");
    addCell(row, unit.id, "req-id");
    addCell(row, unit.type, "type");
    addCell(row, unit.date, "");
    addCell(row, "Expired", "critical");
    table.appendChild(row);
  });

  if (expiredUnits.length === 0) {
    document.getElementById("noExpired").style.display = "block";
  } else {
    document.getElementById("noExpired").style.display = "none";
  }

  updateCards();
}

document.getElementById("removeExpiredBtn").addEventListener("click", function () {

  if (expiredUnits.length === 0) {
    showMessage("expiredMessage", "There are no expired units to remove.", true);
    return;
  }

  if (confirm("Remove all " + expiredUnits.length + " expired unit(s) from stock?")) {
    let count = expiredUnits.length;
    expiredUnits = [];   // empty the array
    showExpired();
    showMessage("expiredMessage", count + " expired unit(s) removed from stock.", false);
  }
});


// ---------- When the page opens ----------

showExpired();
updateCards();
