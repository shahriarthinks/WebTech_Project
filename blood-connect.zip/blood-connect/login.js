/* =====================================================
   Blood Connect - login.js  (used by login.html)
   Sign In part and the Sign In / Create Account tabs.

   Team work (who did what):
   - Sadib        : Registration (Create Account), Admin pages, Forgot Password
   - Sadiha       : Login (Sign In) and Staff dashboard
   - Natasha      : Landing page and Medical Officer dashboard
   - Sadia Mourin : Donor and Receiver dashboards
   This file is done by Sadiha.
   ===================================================== */


// ---------- Tabs: show Sign In or Create Account ----------

const signinTab = document.getElementById("signinTab");
const registerTab = document.getElementById("registerTab");
const signinPanel = document.getElementById("signinPanel");
const registerPanel = document.getElementById("registerPanel");

function showTab(name) {
  if (name === "register") {
    signinPanel.style.display = "none";
    registerPanel.style.display = "block";
    signinTab.classList.remove("active");
    registerTab.classList.add("active");
  } else {
    signinPanel.style.display = "block";
    registerPanel.style.display = "none";
    signinTab.classList.add("active");
    registerTab.classList.remove("active");
  }
}

signinTab.addEventListener("click", function () {
  showTab("signin");
});

registerTab.addEventListener("click", function () {
  showTab("register");
});

// The small links under each form also switch the tab
document.getElementById("goRegister").addEventListener("click", function (event) {
  event.preventDefault();   // stops the link from jumping to the top
  showTab("register");
});

document.getElementById("goSignin").addEventListener("click", function (event) {
  event.preventDefault();
  showTab("signin");
});

// The page opens on the Sign In tab
showTab("signin");


// ---------- Sign In form ----------

const signinForm = document.getElementById("signinForm");

signinForm.addEventListener("submit", function (event) {
  event.preventDefault();   // stops page reload on submit
  clearErrors(signinForm);

  let user = document.getElementById("loginUser");
  let password = document.getElementById("loginPassword");
  let role = document.querySelector('input[name="loginRole"]:checked');

  let valid = true;

  // Role (radio)
  if (role === null) {
    document.getElementById("loginRoleError").innerHTML = "Please choose who you are signing in as.";
    valid = false;
  }

  // Username or email
  if (user.value.trim() === "") {
    showError(user, "loginUserError", "Username or email is required.");
    valid = false;
  } else if (user.value.trim().length < 3) {
    showError(user, "loginUserError", "Must be at least 3 characters.");
    valid = false;
  } else {
    showSuccess(user);
  }

  // Password
  if (password.value === "") {
    showError(password, "loginPasswordError", "Password is required.");
    valid = false;
  } else if (password.value.length < 8) {
    showError(password, "loginPasswordError", "Password must be at least 8 characters.");
    valid = false;
  } else {
    showSuccess(password);
  }

  // Success: open the dashboard of the chosen user type
  if (valid) {
    document.getElementById("loginResult").innerHTML = "Login successful! Opening your dashboard...";

    // role.value is admin, staff, donor, medical-officer or receiver,
    // so the page name becomes admin.html, staff.html and so on.
    // window.location.href opens another page, the same as clicking a link.
    // (Not in the slides: it is the only way to open a page from JavaScript.)
    window.location.href = role.value + ".html";
  }
});


// ---------- Functions (register.js uses these too) ----------

// Show error
function showError(input, errorId, message) {
  input.classList.add("errorBorder");
  input.classList.remove("successBorder");
  document.getElementById(errorId).innerHTML = message;
}

// Show success
function showSuccess(input) {
  input.classList.remove("errorBorder");
  input.classList.add("successBorder");
}

// Clear all errors inside one form
function clearErrors(form) {
  let errors = form.querySelectorAll(".error");
  errors.forEach(function (item) {
    item.innerHTML = "";
  });

  let fields = form.querySelectorAll("input");
  fields.forEach(function (field) {
    field.classList.remove("errorBorder");
    field.classList.remove("successBorder");
  });

  form.querySelector(".result").innerHTML = "";
}
